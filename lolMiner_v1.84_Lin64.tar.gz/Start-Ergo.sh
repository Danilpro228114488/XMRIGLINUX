#!/bin/bash

./lolMiner --algo AUTOLYKOS2 --pool erg.kryptex.network:7777 --user 9i9m9AxmqgBUBD6GfYJQHZiHQ5d6AP7Ak3QVFfKiNtopQnMZkmG/MyFirstRig