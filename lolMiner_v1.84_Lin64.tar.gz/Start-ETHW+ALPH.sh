#!/bin/bash

./lolMiner --algo ETHASH --pool ethw.kryptex.network:7777 --user 0x57462e4A68F5E66012b5A3b44a6E0f19081a605d --worker MyFirstRig --dualmode ALEPHDUAL --dualpool alph.kryptex.network:7777 --dualuser 1Ac3dqv8Jvm33kkDyurxrKNDUBREv5x8RG6xGk726ch7z --dualworker MyFirstRig