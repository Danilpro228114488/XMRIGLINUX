#!/bin/bash

./lolMiner --algo KARLSEN --pool kls.kryptex.network:7777 --user karlsen:qzljplc53rgcsqmz4kwm5n4zgsc250kjdkhr2ze7ax8pp4y30ut0zjy93rse7/MyFirstRig