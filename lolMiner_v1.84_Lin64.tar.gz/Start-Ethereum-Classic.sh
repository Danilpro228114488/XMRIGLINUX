#!/bin/bash

./lolMiner --algo ETCHASH --pool etc.kryptex.network:7777 --user 0x66B64504341874105E989d9A9402D8E2350d48fA/MyFirstRig