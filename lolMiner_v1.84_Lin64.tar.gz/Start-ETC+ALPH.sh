#!/bin/bash

./lolMiner --algo ETCHASH --pool etc.kryptex.network:7777 --user 0x529e3d7050aa576fe3ead29ca321aee2b146727f --worker MyFirstRig --dualmode ALEPHDUAL --dualpool alph.kryptex.network:7777 --dualuser 1Ac3dqv8Jvm33kkDyurxrKNDUBREv5x8RG6xGk726ch7z --dualworker MyFirstRig