#!/bin/bash

./lolMiner --algo IRONFISH --pool iron.kryptex.network:7777 --user 34d4fa52195a4a08ce54497b3e027a3d044d84b23be7f1c0780c40d01589e6e0/MyFirstRig