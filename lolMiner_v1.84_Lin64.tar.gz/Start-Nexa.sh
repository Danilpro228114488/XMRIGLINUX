#!/bin/bash

./lolMiner --algo NEXA --pool nexa.kryptex.network:7777 --user nexa:nqtsq5g5ufvngn8yc2va8nf0ru4mq2d8kh0vr4zzvchqhsy6/MyFirstRig