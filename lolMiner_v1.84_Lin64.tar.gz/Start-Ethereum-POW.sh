#!/bin/bash

./lolMiner --algo ETHASH --pool ethw.kryptex.network:7777 --user 0x5A799e14b2024039EAfAA498d6299fe47FcfE6Df/MyFirstRig