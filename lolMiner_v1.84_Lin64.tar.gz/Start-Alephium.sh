#!/bin/bash

./lolMiner --algo ALEPH --pool alph.kryptex.network:7777 --user 1Ac3dqv8Jvm33kkDyurxrKNDUBREv5x8RG6xGk726ch7z/MyFirstRig