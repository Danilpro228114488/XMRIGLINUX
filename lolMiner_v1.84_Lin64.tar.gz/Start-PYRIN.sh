#!/bin/bash

./lolMiner --algo PYRIN --pool pyi.kryptex.network:7777 --user pyrin:qr64u0p9trj04nr9azfz4z2xuwneexsl6q0kj37z5axr98ca8496cg6hk736u/MyFirstRig